# CSCI 561 USC Spring 2014
# Extra Credit Assignment 1
# Assignment Done by Ansh Bahri

import Myro
from Myro import *
from Graphics import *

cityList =[['a', 60, 170], ['b', 525, 480], ['c', 295, 555], ['d', 165, 530], ['e', 770, 545], ['f', 380, 250], ['g', 480, 585], ['h', 720, 440], ['i', 625, 145], ['l', 165, 385], ['m', 165, 455], ['n', 530, 90], ['o', 110, 25], ['p', 400, 405], ['r', 265, 330], ['s', 225, 235], ['t', 55, 320], ['u', 605, 440], ['v', 680, 260], ['z', 75, 95]]
heuristic = [['a', 366], ['b', 0], ['c', 160], ['d', 242], ['e', 161], ['f', 178], ['g', 77], ['h', 151], ['i', 226], ['l', 244], ['m', 241], ['n', 234], ['o', 380], ['p', 98], ['r', 193], ['s', 253], ['t', 329], ['u', 80], ['v', 199], ['z', 374]]
graph =  [['o', 'z', 71], ['z', 'a', 75], ['o', 's', 151], ['a', 's', 140], ['a', 't', 118], ['t', 'l', 111], ['l', 'm', 70], ['m', 'd', 75], ['d', 'c', 120], ['c', 'r', 146], ['s', 'r', 80], ['c', 'p', 138], ['s', 'f', 99], ['r', 'p', 97], ['f', 'b', 211], ['p', 'b', 101], ['b', 'g', 90], ['b', 'u', 85], ['u', 'h', 98], ['h', 'e', 86], ['u', 'v', 142], ['i', 'v', 92], ['n', 'i', 87]]
openList = []
closedList = []
currentNode = []
parentList = [['a', 'x'], ['b', 'x'], ['c', 'x'], ['d', 'x'], ['e', 'x'], ['f', 'x'], ['g', 'x'], ['h', 'x'], ['i', 'x'], ['l', 'x'], ['m', 'x'], ['n', 'x'], ['o', 'x'], ['p', 'x'], ['r', 'x'], ['s', 'x'], ['t', 'x'], ['u', 'x'], ['v', 'x'], ['z', 'x']]
path = ['b']
x, y = 0, 0

startingCity = raw_input("Enter starting city initial")
#startingCity = 'i'

width, height = 800, 600
sim = Simulation("Romania", width, height, Color("lightgreen"))

picture = makePicture("map1.png")
picture.draw(sim.window)

count = cityList.Count
radius = 20

for i in range(0, count):
    if(i==1):
        sim.addLight((cityList[i][1], cityList[i][2]), radius, Color("white"))
    else:
        sim.addLight((cityList[i][1], cityList[i][2]), radius, Color("green"))

for i in range(0, count):
    if(cityList[i].Contains(startingCity)==True):
        index = i
        break

sim.setup()
robot = makeRobot("SimScribbler", sim)

found = 0
for i in range(0, cityList.Count):
    if(cityList[i].Contains(startingCity)):
        found = 1
        break

if(found==1):
    found = 0
    print(startingCity)
else:
    #die('Invalid Starting City')
    #exit 'EXPR'
    print('Invalid Starting City!! Terminating............')

robot.setPose(cityList[index][1], cityList[index][2], 90)

openList.Add([cityList[i][0],heuristic[i][1],0])
#print('openList', openList)

goalReached = 0
gValue = 0
neighborIndex = -1
breakFlag = 0
continueFlag = 0
minHeuristicInex = -1
tempScore = 0
currentIndex = 0
neighborFoundFlag = 0

#while openList is not empty
#while(openList.Count>0):
while(goalReached!=1):
    minHeauristicValue = 999

    for i in range(0, openList.Count):
        #consider the best node in the open list (the node with the lowest f value)
        if(openList[i][1]<minHeauristicValue):
            minHeauristicValue=openList[i][1]
            minHeuristicInex=i

    #while goal is not reached
    if(openList[minHeuristicInex].Contains('b')):
        print('Goal Reached!!!')
        goalReached = 1

    currentNode.Clear()
    currentNode.Add(openList[minHeuristicInex])
    #print('currentNode', currentNode)
    openList.RemoveAt(minHeuristicInex)
    #print('openList', openList)
    closedList.Add(currentNode[0])
    #print('closedList', closedList)

    currentNodeValue = currentNode[0][2]

    for j in range(0, graph.Count):
        #for each neighbor
        if(graph[j].Contains(currentNode[0][0])):
            if(graph[j][0]==currentNode[0][0]):
                nextNeighbor = graph[j][1]

            else:
                nextNeighbor = graph[j][0]

            #if this neighbor is in the closed list and our current g value is lower
            for k in range(0, closedList.Count):
                if(closedList[k].Contains(nextNeighbor)):
                    #if(closedList[k][1]
                    continueFlag = 1
                    break

            if(continueFlag==1):
                continueFlag = 0
                continue;

            for k in range(0, cityList.Count):
                if(cityList[k].Contains(nextNeighbor)):
                    cityIndex = k
                    break

            tempScore = currentNodeValue + graph[j][2] + heuristic[k][1]
            #print('currentNodeValue', currentNodeValue)
            #print('graph[j][2]', graph[j][2])
            #print('heuristic[k][1]', heuristic[k][1])

            neighborFoundFlag = 0

            #this neighbor is in the open list and our current g value is lower
            for k in range(0, openList.Count):
                if(openList[k].Contains(nextNeighbor)):
                    if(openList[k][2]>tempScore):
                        print('check here.............................')
                        openList[k][2]=tempScore
                        #change parent
                        parentList[cityIndex][1] = currentNode[0][0]
                    continueFlag = 1
                    break;

            if(continueFlag==1):
                continueFlag = 0
                continue;

            #assign parent to node
            parentList[cityIndex][1] = currentNode[0][0]

            #add neighbor city to openList
            #openList.Add([nextNeighbor, heuristic[cityIndex][1]+graph[j][2],currentNodeValue+graph[j][2]])
            openList.Add([nextNeighbor, tempScore, currentNodeValue+graph[j][2]])
            #print('openList', openList)

#print(parentList)
goalCity = parentList[1][1]
parentList.RemoveAt(1)

while(goalCity!=startingCity):
    #robot.setPose(cityList[index][1], cityList[index][2], 90)
    #print(parentList.Count)
    path.Add(goalCity)
    for i in range(0, parentList.Count):
        #print(parentList[i])
        if(parentList[i][0].Contains(goalCity)):
            goalCity = parentList[i][1];
            parentList.RemoveAt(i)
            break

path.reverse()
print(path)

robot.penDown()
while(path.Count != 0):
    for i in range(0, cityList.Count):
        if(cityList[i].Contains(path[0])):
            #robot.setPose(cityList[i][1], cityList[i][2], 90)
            x = cityList[i][1]
            y = cityList[i][2]
            print('x=', x, ' y=', y)
            location = robot.getLocation()
            if(location[0]>x):
                robot.turnTo(180, "deg")
                while(location[0]>x):
                    location = robot.getLocation()
                    forward(1, .2)

            if(location[1]>y):
                robot.turnTo(270, "deg")
                while(location[1]>y):
                    location = robot.getLocation()
                    forward(1, .2)

            if(location[0]<x):
                robot.turnTo(0, "deg")
                while(location[0]<x):
                    location = robot.getLocation()
                    forward(1, .2)

            if(location[1]<y):
                robot.turnTo(90, "deg")
                while(location[1]<y):
                    location = robot.getLocation()
                    forward(1, .2)

            print('location=', location)
            wait(2)
            path.RemoveAt(0)
            break
