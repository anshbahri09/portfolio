# CSCI 561 USC Spring 2014
# Extra Credit Assignment 1
# Assignment Done by Ansh Bahri

import Myro
import Math
import random
from Myro import *
from Graphics import *
from math import exp

cityList =[['a', 60, 170], ['b', 525, 480], ['i', 625, 145], ['n', 530, 90], ['p', 400, 405], ['r', 265, 330], ['s', 225, 235], ['u', 605, 440], ['v', 680, 260], ['z', 75, 95]]
graph =  [['z', 'a', 75], ['a', 's', 140], ['s', 'r', 80], ['r', 'p', 97], ['p', 'b', 101], ['b', 'u', 85], ['u', 'v', 142], ['i', 'v', 92], ['n', 'i', 87], ['z', 'n', 200]]
tempGraph = []
path = []

#startingCity = raw_input("Enter starting city initial")
#startingCity = 'i'

width, height = 800, 600
sim = Simulation("Romania", width, height, Color("lightgreen"))

picture = makePicture("map2.png")
picture.draw(sim.window)

sim.setup()
robot = makeRobot("SimScribbler", sim)

radius = 20
for i in range(0, cityList.Count):
    sim.addLight((cityList[i][1], cityList[i][2]), radius, Color("green"))

startingCity = 'z'
nextCity = 'z'
lastCity = ''

temperature = 101.0        #1000.0
deltaDistance = 0
coolingRate = 0.8           #0.8
absoluteTemperature = 10
distance = 0
total = 0

def totalDistance(city, distance):
    count = 0
    distance = 0

    while (count != cityList.Count-1):
        for i in range(0, graph.Count):
            if(graph[i].Contains(city)):
                #print(graph[i])
                tempGraph.Add(graph[i])
                graph.RemoveAt(i)
                #print(graph[i][2])
                distance = distance + graph[i][2]
                count = count + 1
                if(graph[i][0]==city):
                    city = graph[i][1]
                else:
                    city = graph[i][0]
                #print(city)
                break

    for i in range(0, cityList.Count-1):
        graph.Add(tempGraph[0])
        tempGraph.RemoveAt(0)

    #print('graph', graph)
    return (distance)

def GetNextArrangement(nextCity):
    for i in range(0, graph.Count):
        if(graph[i].Contains(nextCity)):
            break

    if(graph[i][0] == nextCity):
        return (graph[i][1])
    return (graph[i][0])

distance = totalDistance(startingCity, distance)
print('distance', distance)

while (temperature > absoluteTemperature):
    nextCity = GetNextArrangement(nextCity)
    print('nextCity', nextCity)

    total = totalDistance(nextCity, distance)
    deltaDistance = total - distance
    print('total', total)
    print('distance', distance)
    print('deltaDistance', deltaDistance)

    #if the new path has a smaller distance
    if (deltaDistance < 0):
        startingCity = nextCity
        if(distance > 0):
            print(exp(-deltaDistance/temperature))
            print(random())
            if(exp(-deltaDistance/temperature) < random()):
                for i in range(0, graph.Count):
                    #print('startingCity', startingCity)
                    #print(graph[i])
                    if(graph[i].Contains(startingCity)):
                        if(graph[i][0]==startingCity):
                            startingCity = graph[i][1]
                        else:
                            startingCity = graph[i][0]
                        break
            else:
                nextCity = startingCity

        distance = deltaDistance + distance

    #cool down the temperature
    temperature = temperature * coolingRate
    print('temperature', temperature)

print('Final starting city', startingCity)
city = startingCity
path.Add(city)

for j in range(0, cityList.Count-1):
    for i in range(0, graph.Count):
        if(graph[i].Contains(city)):
            #print(graph[i])
            tempGraph.Add(graph[i])
            #print(graph[i][2])
            if(graph[i][0]==city):
                city = graph[i][1]
            else:
                city = graph[i][0]
            graph.RemoveAt(i)
            path.Add(city)
            #print(city)
            break


for i in range(0, cityList.Count):
    if(cityList[i].Contains(startingCity)):
        robot.setPose(cityList[i][1], cityList[i][2], 90)
        break

#path.reverse()
print(path)
robot.penDown()
while(path.Count != 0):
    for i in range(0, cityList.Count):
        if(cityList[i].Contains(path[0])):
            robot.setPose(cityList[i][1], cityList[i][2], 90)
            x = cityList[i][1]
            y = cityList[i][2]
            print('x=', x, ' y=', y)
            location = robot.getLocation()
            print('location=', location)
            wait(2)
            path.RemoveAt(0)
            break