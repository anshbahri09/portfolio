// --*-c++-*--

#include<omp.h>
#include<stdlib.h>
#include<stdio.h>

int min(int a, int b)
{
	if(a<b)
		return a;
	return b;
}

void optMM(int N, double **A, double **B, double **C)
{
  // make the code below optimized matrix multiplication routine

  // you should modify or tweak some/all these to get the better performance
  int nrolls = 8;
  int blockSize = 2;
  int b = blockSize;

  int i = 0, j = 0, k = 0;
  int n = N;
  
/*
	//blocked matrix multiply algorithm
	//waste of time
	for(int i0=0;i0<n;i0+=b)
		for(int j0=0;j0<n;j0+=b)
			for(int k0=0;k0<n;k0+=b)
				for(i=i0; i<min(i0+b, n);i++)
					for(j=j0; j<min(j0+b, n);j++)  
					{						
						if(k==0)
							C[i][j] = 0;
						for(k=k0; k<min(k0+b, n);k++)
						{							
							C[i][j] += A[i][k]*B[k][j];		
						//printf("\ni0 %d j0 %d k0 %d ", i0, j0, k0);
						//printf("A[%d][%d] %d ", i, k, A[i][k]);
						//printf("B[%d][%d] %d ", k, j ,B[k][j]);
						//printf("C[%d][%d] %d", i, j ,C[i][j]);
				//printf("\ni0 %d j0 %d k0 %d, i %d j %d k %d C[i][j] %d", i0, j0, k0, i, j, k, C[i][j]);
						}
					}
*/
/*
	//changing order of iterators
	for(i=0; i<n; i++)                        
		for(k=0; k<n; k++)
			for(j=0; j<n; j++)
				C[i][j] += A[i][k]*B[k][j];
*/  
/*
	//good  
	//loop unrolling
	//presents a problem if degree of unrolling is not a factor of N
	for(i=0; i<n; i++)                        
		for(j=0; j<n; j++)   
		{
		//	C[i][j] = 0;
			for(k=0; k<n; k+=2)
			{
				C[i][j] += A[i][k]*B[k][j];
				C[i][j] += A[i][k+1]*B[k+1][j];
			}
		}
*/
/*
	//Cache blocking
	for(int bi=0; bi<n; bi+=blockSize)
		for(int bj=0; bj<n; bj+=blockSize)
			for(int bk=0; bk<n; bk+=blockSize)
				for(int i=0; i<blockSize; i++)
					for(int j=0; j<blockSize; j++)
						for(int k=0; k<blockSize; k++)					  
							C[bi+i][bj+j] += A[bi+i][bk+k]*B[bk+k][bj+j];					
*/
	
	//good		// try this also.
	//Blocked (Tiled) Matrix Multiply
	//using temporary variables
    for (int i = 0; i < N; i++) {
        double* iRowA = A[i];		//read in fast memory
        double* iRowC = C[i];
        for (int k = 0; k < N; k++) {
            double* kRowB = B[k];	//read in fast memory
            double ikA = iRowA[k];
            for (int j = 0; j < N; j++) {
                iRowC[j] += ikA * kRowB[j];		//write in slow memory
            }
        }
    }

  return;
}

