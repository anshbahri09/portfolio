// --*-c++-*--

#include<omp.h>
#include<stdlib.h>
#include<stdio.h>	

int ompMF(int ld, double** matrix)
{ 
	// please change the code below to parallel implementation
	double diag;
	int error = 0;
	int i, j, k;

	//int th_id, max_threads;

	//max_threads = omp_get_max_threads();
	//max_threads = 4;
	//printf("max threads = %d\n", max_threads);
	//omp_set_num_threads(max_threads);	//set the number of threads
	omp_set_num_threads(10);				//try different values
	#pragma omp parallel private(i, j, k)// shared(matrix) private(th_id)
	//{
		//int i, j, k;		//iterators
		//th_id = omp_get_thread_num();
		//printf("thread id %d\n", th_id);
			//th_id holds the thread number for each thread
		
		//split the first for loop among the threads
		
		//#pragma omp for
		//cannot parallelize because i+1st iteration uses values from ith iteration
		for (int k=0; k<ld; k++)
		{
			if (matrix[k][k] == 0.0)
			{
				error = 1;
			//	#pragma omp barrier
				break;
			//	return error;
			}
			diag = 1.0 / matrix[k][k];
			
			#pragma omp for
			for (i=k+1; i < ld; i++)
			  matrix[k][i] = diag * matrix[k][i];
			
			#pragma omp for
			for (i=k+1; i<ld; i++)
				for (j=k+1; j<ld; j++)
					matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];
		}	
	//}

  return error;
}