// --*-c++-*--

#include<omp.h>
#include<stdio.h>
#include<stdlib.h>

void ompMM(int N, double **A, double **B, double **C)
{
	//int th_id;
	//int max_threads;
	int i, j, k;
	
	//max_threads = omp_get_max_threads();
			//comment below to give default no of threads
	//omp_set_num_threads(max_threads);	//set the number of threads
	//printf("\nmax threads = %d\n", max_threads);
	omp_set_num_threads(10);				//try different values
	#pragma omp parallel for private(i, j, k)//shared(A, B, C) //private(th_id)
	//{
		//int i, j, k;		//iterators
		//th_id = omp_get_thread_num();
		//printf("thread id %d\n", th_id);
			//th_id holds the thread number for each thread
			
		//split the first for loop among the threads
		//#pragma omp for
		for(i=0;i<N;i++)	//iterate through the rows of the result
		//{
			//printf("thread #%d is doing row %d.\n", th_id, i); //uncomment this line to see which thread is doing which row
			for(j=0;j<N;j++)	//iterate throught the columns of the result
			//{
				//*(C+(j+i*N))=0;	//initialize
				//C[i][j]=0;
				for(k=0;k<N;k++)
					C[i][j] += A[i][k] * B[k][j];
			//}
		//}
	//}

  	return;
}
