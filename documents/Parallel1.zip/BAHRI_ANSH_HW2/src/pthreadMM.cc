#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

struct args_struct
{
	double **argA;
	double **argB;
	double **argD;
	int argN;
};	
args_struct args;

//int argSlice;
int num_thrd = 10;				//number of threads. Try different values

void *multiply(void *slice)
{
	int i=0, j=0, k=0;
	int from=0, to=0;
	int argSlice;
	//struct args_struct *args;
	//double temp_sum = 0;
	//args = (struct args_struct*) arguments;

	argSlice = (int)slice;
	from = (argSlice * args.argN) / num_thrd;	//note that this slicing works fine
	to = ((argSlice + 1) * args.argN) / num_thrd;	//even if SIZE is not divisible by num_thrd
	
	//printf("computing slice %d (from row %d to %d)\n", argSlice, from, to-1);
	for(i=from;i<to;i++)
	{
		for(j=0;j<args.argN;j++)
		{	//args->argD[i][j]=0;
			//temp_sum = 0;
			for(k=0;k<args.argN;k++)
				//temp_sum += args->argA[i][k] * args->argB[k][j];
				//args->argD[i][j] += args->argA[i][k] * args->argB[k][j];
				args.argD[i][j] += args.argA[i][k] * args.argB[k][j];
			//printf("%d,%d,%d ", i,j,args->argD[i][j]);
			//printf("j %d ", j);			
		}
		//args->argD[i][j] = temp_sum;
		//printf("i %d \n", i);
	}
	//printf("finished slice %d\n", argSlice);	
	//pthread_exit(NULL);
	//printf("\nhere\n");
	return 0;
}

void pthreadMM(int N, double **A, double **B, double **D)
{
	//printf("\nStart\n");
	//struct args_struct *args;
	pthread_t* thread;	//pointer to a group of the threads
	int i=0, j=0, argSlice = 0;

	//num_thrd = N+1;
	//printf("D = %d ", D);
	//args = (args_struct*)malloc(sizeof(struct args_struct));

	args.argA = A;
	args.argB = B;
	args.argD = D;
	args.argN = N;
	//printf("argD = %d ", args->argD);
	
	thread = (pthread_t*) malloc(num_thrd*sizeof(pthread_t));

	for(i=1;i<num_thrd;i++)
	{	
		//creates each thread working on its own slice of i
		argSlice = i;
		if(pthread_create(&thread[i], NULL, multiply, (void*)argSlice) != 0)
		{
			perror("Can't create thread");
			free(thread);
			exit(-1);
		} 
	}
	//argSlice = 0;
	multiply(0);		//master thread
	//pthread_exit(NULL);
	
	for(i=1;i<num_thrd;i++)
		pthread_join(thread[i], NULL); 
	
	//D = args->argD;
	//printf("\nDnew = %d\n", D);
	
	free(thread);

	return;
}
