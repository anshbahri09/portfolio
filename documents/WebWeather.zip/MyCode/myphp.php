<?php
	$location = $_GET['location'];
	$zip_check = '/^\d{5}$/';
	if(preg_match($zip_check, $_GET['location']))
	{
		$type = "ZIP_Code";
	}
	else
	{
		$type = "City";
	}
	
	if($type=="City")
	{	
		$city=$_GET['location'];
			
		$encode = urlencode($city);					
		$url_post = "http://where.yahooapis.com/v1/places.q('$encode')?appid=NZQYNhDV34EqopWznFcyCK1SZeF6Lt_2JhBZNarss2ms5Ugp0Y74yBZ5Q3Zmm7Q-";
		
		$file = "weather.xml";
		$data = @file_get_contents($url_post);
		@file_put_contents($file, $data);
		
		$weather_feed = @file_get_contents($url_post);
		$objDOM = new DOMDocument();
		$objDOM->loadXML($weather_feed);
		
		$woeid = $objDOM->getElementsByTagName("place")->item($x)->getElementsByTagName("woeid")->item(0)->nodeValue;	
		$theURL = "http://weather.yahooapis.com/forecastrss?w=$woeid&u=$u";
		$fileXML = @file_get_contents($theURL);
		
		$file = "woeid.xml";
		$data = @file_get_contents($theURL);
		@file_put_contents($file, $data);
	}

	else if($type=="ZIP_Code")
	{
		$zip = $_GET['location'];
	
		$url_post="http://where.yahooapis.com/v1/concordance/usps/".$zip."?appid=NZQYNhDV34EqopWznFcyCK1SZeF6Lt_2JhBZNarss2ms5Ugp0Y74yBZ5Q3Zmm7Q-";
		$weather_feed = @file_get_contents($url_post);
		
		$file = "weather.xml";
		$data = @file_get_contents($url_post);
		@file_put_contents($file, $data);
	
		if(urlencode($weather_feed)=="")
		{
			echo "<script>alert('Error. Try again.')</script>";
			return;
		}
			
		$objDOM = new DOMDocument();
		$objDOM->loadXML($weather_feed);
		$father = $objDOM->getElementsByTagName("concordance");
		$count = $father->length;
		
		$woeid = $father->item(0)->getElementsByTagName("woeid")->item(0)->nodeValue;
		$theURL = "http://weather.yahooapis.com/forecastrss?w=$woeid&u=$u";
		$fileXML = @file_get_contents($theURL);
		
		$file = "woeid.xml";
		$data = @file_get_contents($theURL);
		@file_put_contents($file, $data);
	}
?>