void callback()
{
	var TextEntry = document.getElementById("TextEntry").value;
	
	if(TextEntry == "")
		alert("Please enter value!");
	else 
		TextEntry = TextEntry.replace(" ", "+");
	
	if(window.XMLHttpRequest)
		req = new XMLHttpRequest();
	else if(window.ActiveXObject)
		req = new ActiveXObject("Microsoft.XMLHTTP");

	if(req) {
		var Url = "http://cs-server.usc.edu:12304/servlet/MyServlet?TextEntry="+TextEntry;
		
		req.open("GET", url, true);
		req.onreadystatechange = myCallback;
		req.setRequestHeader("connection", "close");
		req.setRequestHeader("method", "GET" + url + "HTTP/1.1");
		req.send();
		document.getElementById("info").innerHTML = "Welcome";
	}
	
	else
		document.getElementById("info").innerHTML = "Sorry";
}