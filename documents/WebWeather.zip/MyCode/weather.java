import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.xml.parsers.*;

public class weather extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		response.setContentType("text/plain");
		
		String location = request.getParameter("location");
		String type = request.getParameter("type");
		String u = request.getParameter("u");
		location = location.replaceAll(" ", "+");
		String urlString = "http://localhost/web_tech_hw/setup/myphp.php?location="+location+"&type="+type+"&u="+u;
		URL url = new URL(urlString);
		URLConnection urlConnection = url.openConnection();
		urlConnection.setAllowUserInteraction(false);
		InputStream urlStream = url.openStream();
	}
}