package com.example.androidweather;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.Session.StatusCallback;

public class MainActivity extends Activity {

	private static final StatusCallback StatusCallback = null;
	private EditText editText1;
	private RadioButton radio0;
	private RadioButton radio1;
	String city, region, country, imageurl, conditiontext, conditiontemp, feed;
	String loc, type, u;
	String line3;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void test(View view)	{		
		editText1 = (EditText)findViewById(R.id.editText1);
		loc = editText1.getText().toString();				
		
		radio0 = (RadioButton)findViewById(R.id.radio0);
		radio1 = (RadioButton)findViewById(R.id.radio1);
		
		if(radio0.isChecked()) {
			u="f";			
		}		
		
		if(radio1.isChecked()) {
			u="c";
		}
		
		Pattern pattern_zip = Pattern.compile("^[0-9]{5}$");
Pattern pattern_city = Pattern.compile("((( )*[a-zA-Z]+( )*)+)((,)(( )*[a-zA-Z]+( )*)+){1,2}");
		Matcher matcher_zip = pattern_zip.matcher(loc);
		Matcher matcher_city = pattern_city.matcher(loc);
		
		if(matcher_zip.find()) {
			type="zip";
		}
		else if(matcher_city.find()) {
			type="city";
		}
		else {
Toast.makeText(getApplicationContext(), "Enter location or zip again!! Example - 'Los Angeles, CA' or '90007'", Toast.LENGTH_SHORT).show();
			return;
		}		
		
		loc = loc.replaceAll(" ", "");
		loc = loc.replace(",", "%2C");
		loc = loc.replace(".", "");
		//loc = loc.split(",");
						
		TextView textview1 = (TextView) findViewById(R.id.textView1);
		TextView textview2 = (TextView) findViewById(R.id.textView2);
		TextView textview3 = (TextView) findViewById(R.id.textView3);
		TextView textview4 = (TextView) findViewById(R.id.textView4);
		TextView textview5 = (TextView) findViewById(R.id.textView5);
		TextView textview6 = (TextView) findViewById(R.id.textView6);
		TextView textview7 = (TextView) findViewById(R.id.textView7);
		TableLayout tablelayout1 = (TableLayout) findViewById(R.id.tableLayout1);
		TableRow tableRow1 = (TableRow) findViewById(R.id.tableRow1);
		TableRow tableRow2 = (TableRow) findViewById(R.id.tableRow2);
		TableRow tableRow3 = (TableRow) findViewById(R.id.tableRow3);
		TableRow tableRow4 = (TableRow) findViewById(R.id.tableRow4);
		TableRow tableRow5 = (TableRow) findViewById(R.id.tableRow5);
		TableRow tableRow6 = (TableRow) findViewById(R.id.tableRow6);
		TextView row1col1 = (TextView)	findViewById(R.id.row1col1);
		TextView row1col2 = (TextView)	findViewById(R.id.row1col2);
		TextView row1col3 = (TextView)	findViewById(R.id.row1col3);
		TextView row1col4 = (TextView)	findViewById(R.id.row1col4);
		TextView row2col1 = (TextView)	findViewById(R.id.row2col1);
		TextView row2col2 = (TextView)	findViewById(R.id.row2col2);
		TextView row2col3 = (TextView)	findViewById(R.id.row2col3);
		TextView row2col4 = (TextView)	findViewById(R.id.row2col4);
		TextView row3col1 = (TextView)	findViewById(R.id.row3col1);
		TextView row3col2 = (TextView)	findViewById(R.id.row3col2);
		TextView row3col3 = (TextView)	findViewById(R.id.row3col3);
		TextView row3col4 = (TextView)	findViewById(R.id.row3col4);
		TextView row4col1 = (TextView)	findViewById(R.id.row4col1);
		TextView row4col2 = (TextView)	findViewById(R.id.row4col2);
		TextView row4col3 = (TextView)	findViewById(R.id.row4col3);
		TextView row4col4 = (TextView)	findViewById(R.id.row4col4);
		TextView row5col1 = (TextView)	findViewById(R.id.row5col1);
		TextView row5col2 = (TextView)	findViewById(R.id.row5col2);
		TextView row5col3 = (TextView)	findViewById(R.id.row5col3);
		TextView row5col4 = (TextView)	findViewById(R.id.row5col4);
		TextView row6col1 = (TextView)	findViewById(R.id.row6col1);
		TextView row6col2 = (TextView)	findViewById(R.id.row6col2);
		TextView row6col3 = (TextView)	findViewById(R.id.row6col3);
		TextView row6col4 = (TextView)	findViewById(R.id.row6col4); 
		ImageView imageview1 = (ImageView) findViewById(R.id.imageView1);
		String returnString = "";
		
String urll = "http://68.181.195.44:12304/examples/servlet/WeatherServlet?location=" + loc + "&type=" + type + "&u=" + u;		
		
		if(u=="f")
			u="F";
		if(u=="c")
			u="C";

		try{
		    URL url = new URL(urll);
		    URLConnection connection = url.openConnection();
		    connection.setDoOutput(true);		 
		    InputStream getinputstream;
		    getinputstream = connection.getInputStream();
		    InputStreamReader inputstream = new InputStreamReader(getinputstream);		    
		    BufferedReader in = new BufferedReader(inputstream);		    
		    returnString = in.readLine();		    
		    in.close();		
	    } catch(Exception e)
	    {
	    	//textview1.setText("1" + e.toString());
	        Log.d("Exception", e.toString());
	    }				
		
		try {
			if(returnString.indexOf("IOException")!=-1) {
				textview1.setText("Weather information cannot be found!");
				textview2.setText("");
				textview3.setText("");
				textview4.setText("");
				textview5.setText("");
				textview6.setText("");
				textview7.setText("");
				tablelayout1.removeAllViewsInLayout();
				imageview1.setVisibility(imageview1.INVISIBLE);
				return;
			}
			
			JSONObject mainObject = new JSONObject(returnString);
			JSONObject weatherObject = mainObject.getJSONObject("weather");
			JSONObject locationObject = weatherObject.getJSONObject("location");
			JSONObject conditionObject = weatherObject.getJSONObject("condition");
			JSONArray forecastArray = weatherObject.getJSONArray("forecast");			
			city = locationObject.getString("city");
			region = locationObject.getString("region");
			country = locationObject.getString("country");
			imageurl = weatherObject.getString("image");
			feed = weatherObject.getString("feed");
			conditiontext = conditionObject.getString("text");
			conditiontemp = conditionObject.getString("temp");
			//JSONArray weather = forecastObject.getJSONArray()
			textview1.setText(city);
			textview2.setText(region + ", " + country);			
			Bitmap bitmap = BitmapFactory.decodeStream((InputStream)new URL(imageurl).getContent());
			imageview1.setImageBitmap(bitmap);
			textview3.setText(conditiontext);
			textview4.setText(conditiontemp + "�" + u);			
			textview5.setText("Forecast");
			tableRow1.setBackgroundColor(Color.GRAY);	
			tableRow2.setBackgroundColor(Color.WHITE);
			tableRow3.setBackgroundColor(Color.CYAN);
			tableRow4.setBackgroundColor(Color.WHITE);
			tableRow5.setBackgroundColor(Color.CYAN);
			tableRow6.setBackgroundColor(Color.WHITE);
			row1col1.setText("Weather");
			row1col2.setText("High");
			row1col3.setText("Day");
			row1col4.setText("Low");
			JSONObject json_data;
			json_data = forecastArray.getJSONObject(0);		
			row2col1.setText(json_data.getString("Weather"));
			row2col2.setText(json_data.getString("High") + "�" + u);
			row2col3.setText(json_data.getString("Day"));
			row2col4.setText(json_data.getString("Low") + "�" + u);
line3 = json_data.getString("Day") + ": " + json_data.getString("Weather") + ", "
			+ json_data.getString("Low") + "/" + json_data.getString("High") + "�" + u +"; ";
			json_data = forecastArray.getJSONObject(1);
			row3col1.setText(json_data.getString("Weather"));
			row3col2.setText(json_data.getString("High") + "�" + u);
			row3col3.setText(json_data.getString("Day"));
			row3col4.setText(json_data.getString("Low") + "�" + u);
line3 += json_data.getString("Day") + ": " + json_data.getString("Weather") + ", "
			+ json_data.getString("Low") + "/" + json_data.getString("High") + "�" + u +"; ";			
			json_data = forecastArray.getJSONObject(2);
			row4col1.setText(json_data.getString("Weather"));
			row4col2.setText(json_data.getString("High") + "�" + u);
			row4col3.setText(json_data.getString("Day"));
			row4col4.setText(json_data.getString("Low") + "�" + u);
line3 += json_data.getString("Day") + ": " + json_data.getString("Weather") + ", "
			+ json_data.getString("Low") + "/" + json_data.getString("High") + "�" + u +"; ";						
			json_data = forecastArray.getJSONObject(3);
			row5col1.setText(json_data.getString("Weather"));
			row5col2.setText(json_data.getString("High") + "�" + u);
			row5col3.setText(json_data.getString("Day"));
			row5col4.setText(json_data.getString("Low") + "�" + u);
line3 += json_data.getString("Day") + ": " + json_data.getString("Weather") + ", "
			+ json_data.getString("Low") + "/" + json_data.getString("High") + "�" + u +"; ";						
			json_data = forecastArray.getJSONObject(4);
			row6col1.setText(json_data.getString("Weather"));
			row6col2.setText(json_data.getString("High") + "�" + u);
			row6col3.setText(json_data.getString("Day"));
			row6col4.setText(json_data.getString("Low") + "�" + u);	
line3 += json_data.getString("Day") + ": " + json_data.getString("Weather") + ", "
			+ json_data.getString("Low") + "/" + json_data.getString("High") + "�" + u +"; ";			
			
			textview6.setText("Share Current Weather");
			textview7.setText("Share Weather Forecast");	
			
			textview6.setOnClickListener(new OnClickListener() {
				final Context context = MainActivity.this;
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub									
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);						
					//alertDialogBuilder.setTitle("Your Title");
		 
					// set dialog message
					alertDialogBuilder
						.setMessage("Post to Facebook")
						.setCancelable(false)
						.setPositiveButton("Post Current Weather",new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,int id) {
								// if this button is clicked, close
								// current activity
								//MainActivity.this.finish();
								String line1 = city + ", " + region + ", " + country;
				String line2 = "The current condition for " + city + " is " + conditiontext;
								String line3 = "Temperature is " + conditiontemp + "�" + u;						
								
								Intent intent = new Intent(MainActivity.this, Fb_login.class);								
								intent.putExtra("line1", line1)
									.putExtra("line2", line2)
									.putExtra("line3", line3)
									.putExtra("imageurl", imageurl)
									.putExtra("feed", feed);
								startActivity(intent);								
							}
						  })
						.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,int id) {
								// if this button is clicked, just close
								// the dialog box and do nothing
								dialog.cancel();
							}
						});
		 
						// create alert dialog
						AlertDialog alertDialog = alertDialogBuilder.create();
		 
						// show it
						alertDialog.show();	            
				}

			});
			
			textview7.setOnClickListener(new OnClickListener() {
				final Context context = MainActivity.this;
				
				@Override
				public void onClick(View view) {
					// TODO Auto-generated method stub									
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);						
					//alertDialogBuilder.setTitle("Your Title");
		 
					// set dialog message
					alertDialogBuilder
						.setMessage("Post to Facebook")
						.setCancelable(false)
						.setPositiveButton("Post Weather Forecast",new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,int id) {
								// if this button is clicked, close
								// current activity
								//MainActivity.this.finish();
								String line1 = city + ", " + region + ", " + country;
							String line2 = "Weather forecast for " + city + " is " + conditiontext;
							
							Intent intent = new Intent(MainActivity.this, Fb_login.class);
							intent.putExtra("line1", line1)
								.putExtra("line2", line2)
								.putExtra("line3", line3)
								.putExtra("imageurl", imageurl)
								.putExtra("feed", feed);
							startActivity(intent);
								
							}
						  })
						.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,int id) {
								// if this button is clicked, just close
								// the dialog box and do nothing
								dialog.cancel();
							}
						});
		 
						// create alert dialog
						AlertDialog alertDialog = alertDialogBuilder.create();
		 
						// show it
						alertDialog.show();
				}
			});
			
		} catch (JSONException e) {			
			// TODO Auto-generated catch block	
			//textview2.setText("2" + e.toString());
			e.printStackTrace();			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block	
			//textview3.setText("3" + e.toString());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//textview4.setText("4" + e.toString());
			e.printStackTrace();
		}		

		//textview1.setText(doc);
		//Toast.makeText(getApplicationContext(), "here", Toast.LENGTH_SHORT).show();
	}
}