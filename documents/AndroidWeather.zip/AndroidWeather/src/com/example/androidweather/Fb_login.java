package com.example.androidweather;

import com.facebook.android.DialogError;
import com.facebook.android.Facebook;
import com.facebook.android.FacebookError;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.facebook.android.Facebook.DialogListener;

public class Fb_login extends Activity {
	private static final String APP_ID = "260819057402155";
	private static final String[] PERMISSIONS = new String[] {"publish_stream"};
	private static final String TOKEN = "access_token";
	private static final String EXPIRES = "expires_in";
	private static final String KEY = "facebook-credentials";

	private Facebook facebook;
	private String line1;
	private String line2;
	private String line3;
	private String imageurl;
	private String postmsg;
	private String feed;
	
	public boolean saveCredentials(Facebook fb)	{
	Editor editor = getApplicationContext().getSharedPreferences(KEY, Context.MODE_PRIVATE).edit();
	editor.putString(TOKEN, fb.getAccessToken());
	editor.putLong(EXPIRES, fb.getAccessExpires());
	return editor.commit();				
	}
	
	@SuppressWarnings("deprecation")
	public boolean restoreCredentials(Facebook facebook) {
    	SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(KEY, Context.MODE_PRIVATE);
    	facebook.setAccessToken(sharedPreferences.getString(TOKEN, null));
    	facebook.setAccessExpires(sharedPreferences.getLong(EXPIRES, 0));
    	return facebook.isSessionValid();
	}
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		facebook = new Facebook(APP_ID);
		restoreCredentials(facebook);

		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		//setContentView(R.layout.share_on_facebook_activity);
		Intent fb_intent = getIntent();
		line1=fb_intent.getStringExtra("line1");
		line2=fb_intent.getStringExtra("line2");
		line3=fb_intent.getStringExtra("line3");
		imageurl=fb_intent.getStringExtra("imageurl");
		feed=fb_intent.getStringExtra("feed");
		postmsg="Post to Wall";
		loginAndPostToWall();
		finishActivity(0);
	}
	
	public void doNotShare(View button){
		finish();
	}
	
	public void share(View button){
		if (! facebook.isSessionValid()) {
			loginAndPostToWall();
		}
		else {
			postToWall(postmsg);
		}
	}
	
	public void loginAndPostToWall(){
		 facebook.authorize(this, PERMISSIONS, Facebook.FORCE_DIALOG_AUTH, new LoginDialogListener());
	}
	
	public void postToWall(String message){
		Bundle parameters = new Bundle();
		
        parameters.putString("picture", imageurl);
	    parameters.putString("name", line1);
	    parameters.putString("link", feed);
	    parameters.putString("caption", line2);
	    parameters.putString("description", line3);
	    parameters.putString("properties", "{\"Look at details\" : {\"text\" : \"here\",\"href\" : \""+ feed +"\"}}");
	
        facebook.dialog(this, "feed", parameters, new Facebook.DialogListener() {
        	public void onComplete(Bundle values) {
        		final String postId = values.getString("post_id");
        		if (postId != null) {
        			Toast.makeText(getApplicationContext(), "Post success", Toast.LENGTH_SHORT).show();
        		    finish();
        		}
	            else {
	            	Toast.makeText(getApplicationContext(), "Post failed", Toast.LENGTH_SHORT).show();
	            }
	    	}

			@Override
			public void onFacebookError(FacebookError e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onError(DialogError e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onCancel() {
				// TODO Auto-generated method stub
				
			}
        });	
	}
	
	class LoginDialogListener implements DialogListener {
	    public void onComplete(Bundle values) {
	    	saveCredentials(facebook);
	    	if (postmsg != null){
			postToWall(postmsg);
		}
	    }
	    public void onFacebookError(FacebookError error) {
	    	showToast("Authentication with Facebook failed!");
	        finish();
	    }
	    public void onError(DialogError error) {
	    	showToast("Authentication with Facebook failed!");
	        finish();
	    }
	    public void onCancel() {
	    	showToast("Authentication with Facebook cancelled!");
	        finish();
	    }
	}
	
	private void showToast(String message){
		Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.share_on_facebook_activity, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		//switch (item.getItemId()) {
		//case android.R.id.home:
			//NavUtils.navigateUpFromSameTask(this);
			//return true;
		//}
		return super.onOptionsItemSelected(item);
	}
}