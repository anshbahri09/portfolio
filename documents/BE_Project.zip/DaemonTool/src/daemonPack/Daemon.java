/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package daemonPack;

import java.io.*;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import JavaLib.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import libPack.ServerCommand;
import libPack.ServerInfo;



class ScanTimerTask extends TimerTask {
    public Daemon parent;
    int progressCount;
    
    public ScanTimerTask(Daemon parent) {
        this.parent = parent;
        progressCount = 0;

    }

    public void setProcess(String str) {
        parent.jTextProcess.setText(str);
    }

    public void setStatus(String str) {
        parent.jTextStatus.setText(str);
    }

    public void addStatus(String str) {
        parent.jTextStatus.setText(str + "\n" + parent.jTextStatus.getText());
    }

    public void run() {
        if(!parent.runningScan) {
            parent.jProgressBar1.setValue(0);
            return;
        }
        
        progressCount++;
        if(progressCount==11) {
            progressCount = 0;
        }
        parent.jProgressBar1.setValue(progressCount);
        
        try {
            ServerInfo si = new ServerInfo();
            si.name = parent.serverName;
            si.ip = parent.serverIP;
            
            // check if parent has some response ready to be transmitted...
            if(parent.responseCode!=0) {
                addStatus("Submitting Response");
                si.responseCode = parent.responseCode;
                si.response.response.clear();
                for(int i=0;i<parent.response.size();i++) {
                    si.response.response.add(parent.response.get(i));
                }
                parent.responseCode = 0; // so that repeated response reports are not sent...
            }
            
            // submit to parent....
            String urlstr = "http://" + parent.jTextServer.getText() + ":8084/ClientServlets/FromServer";
            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();

            connection.setDoOutput(true);
            connection.setDoInput(true);

            // don't use a cached version of URL connection
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);

            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
            out.writeObject(si);
            out.close();
            
            InputStream in = connection.getInputStream();
            int length = connection.getContentLength();
            String response = "";
            int c;
            for(int i=0;i<length;i++) {
                response += (char)in.read();
            }
            in.close();
            parent.jTextStatusBar.setText("CLIENT RESPONSE: " + response);
        }catch(Exception e) {
            parent.jTextStatusBar.setText("ERROR SENDING INFO!");
            System.out.println("Exception Sending Information: " + e);
        }
        
        try { Thread.sleep(500); } catch(Exception e) { ; }
        
        // now check if server has some command ready for client
        try {
            String urlstr = "http://" + parent.jTextServer.getText() + ":8084/ClientServlets/ToServer";
            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();

            connection.setDoOutput(true);
            connection.setDoInput(true);

            // don't use a cached version of URL connection
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            
            ServerInfo si = new ServerInfo();
            si.name = parent.serverName; // so that servlet's knows which server commands to fetch...
            
            ObjectOutputStream out2 = new ObjectOutputStream(connection.getOutputStream());
            out2.writeObject(si);
            out2.close();
            
            ServerCommand sc = new ServerCommand();
            ObjectInputStream in2 = new ObjectInputStream(connection.getInputStream());
            sc = (ServerCommand)in2.readObject();
            in2.close();
            
            if(sc.sc.commandType == -1) {
                parent.jTextStatusBar.setText("NO COMMANDS AVAILABLE");
            }else {
                // process commands and set parent.responseCode & parent.response...
                System.out.println("COMMAND: " + sc.sc.commandTypeDesc[sc.sc.commandType]);
                parent.jTextStatusBar.setText("COMMAND FETCHED");
                addStatus("COMMAND RECEIVED: " + sc.sc.commandTypeDesc[sc.sc.commandType]);
                switch(sc.sc.commandType) {
                    case 1: // read file...
                        addStatus("READ FILE (" + sc.sc.command.get(0) + ") COMMAND RECEIVED");
                        parent.responseCode = 1;
                        parent.response.clear();
                        try {
                            String contents = "", temp;
                            BufferedReader br = new BufferedReader(new FileReader(sc.sc.command.get(0)));
                            while((temp=br.readLine())!=null) {
                                contents += temp + "\n";
                            }
                            br.close();
                            setProcess("Contents: " + contents);
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("CONTENTS: " + contents);
                        }catch(Exception e) {
                            setProcess("STATUS: Error Reading [" + e + "]");
                            System.out.println("Error Reading File: " + e);
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Error Reading [" + e + "]");
                        }
                        break;
                    case 2: // create file...
                        parent.addText("CREATE FILE (" + sc.sc.command.get(0) + ") COMMAND RECEIVED");
                        parent.responseCode = 2;
                        parent.response.clear();
                        try {
                            BufferedWriter bw = new BufferedWriter(new FileWriter(sc.sc.command.get(0)));
                            bw.write(sc.sc.command.get(1));
                            bw.close();
                            setProcess("CREATED FILE : " + sc.sc.command.get(0));
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Created Successfully!");
                        }catch(Exception e) {
                            setProcess("STATUS: Error Creating [" + e + "]");
                            System.out.println("Error Creating File: " + e);
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Error Creating [" + e + "]");
                        }
                        break;
                    case 3: // delete file
                        parent.addText("DELETE FILE (" + sc.sc.command.get(0) + ") COMMAND RECEIVED");
                        parent.responseCode = 3;
                        parent.response.clear();
                        try {
                            new File(sc.sc.command.get(0)).delete();
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Deleted Successfully!");
                            setProcess("STATUS: Deleted Successfully!");
                        }catch(Exception e) {
                            setProcess("STATUS: Error Deleting [" + e + "]");
                            System.out.println("Error Deleting File: " + e);
                            parent.response.add("FILE: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Error Deleting [" + e + "]");
                        }
                        break;
                    case 4: // list files...
                        parent.addText("LIST FILES FOR (" + sc.sc.command.get(0) + ")");
                        parent.responseCode = 4;
                        parent.response.clear();
                        parent.response.add("DIRECTORY LISTING FOR: " + sc.sc.command.get(0));
                        try {
                            File f = new File(sc.sc.command.get(0));
                            File files[] = f.listFiles();
                            for(int i=0;i<files.length;i++) {
                                parent.response.add(files[i].getName());
                                System.out.println("Files: " + files[i].getName());
                            }
                            setProcess("STATUS: LIST RETRIEVED!");
                        }catch(Exception e) {
                            setProcess("STATUS: Error Fetching [" + e + "]");
                            System.out.println("Error Reading File: " + e);
                            parent.response.add("DIRECTORY LISTING FOR: " + sc.sc.command.get(0));
                            parent.response.add("STATUS: Error Fetching [" + e + "]");
                        }
                        break;
                    case 5: // execute only...
                    {
                        parent.addText("CALL PROCESS (" + sc.sc.command.get(0) + ") COMMAND RECEIVED");
                        parent.responseCode = 5;
                        parent.response.clear();
                        parent.response.add("PROCESS: " + sc.sc.command.get(0));
                        try {
                            ProcessBuilder pb = new ProcessBuilder(sc.sc.command);
                            if(!sc.sc.directory.equals("")) {
                                pb.directory(new File(sc.sc.directory));
                            }
                            Process p = pb.start();
                            parent.response.add("STATUS: Executed/Called Successfully!");
                            setProcess("STATUS: Executed/Called Successfully!");
                        }catch(Exception e) {
                            setProcess("STATUS: Error Calling [" + e +"]");
                            System.out.println("Error Shutting Down: " + e);
                            parent.response.add("STATUS: Error Calling [" + e +"]");
                        }
                    }
                    break;
                    case 6: // execute with feedback....
                    {
                        parent.addText("CALL PROCESS WITH F/B (" + sc.sc.command.get(0) + ") COMMAND RECEIVED");
                        parent.responseCode = 6;
                        parent.response.clear();
                        parent.response.add("PROCESS: " + sc.sc.command.get(0));
                        try {
                            ProcessBuilder pb = new ProcessBuilder(sc.sc.command);
                            if(!sc.sc.directory.equals("")) {
                                pb.directory(new File(sc.sc.directory));
                            }
                            Process p = pb.start();

                            String res = "";
//                            InputStreamReader tempReader = new InputStreamReader(new BufferedInputStream(p.getErrorStream()));
//                            BufferedReader reader = new BufferedReader(tempReader);
//                            while (true){
//                                String line = reader.readLine();
//                                if (line == null)
//                                    break;
//                                res += line + "\n";
//                            }
//                            reader.close();
//                            parent.response.add("ERROR STREAM: " + res);
                            res = "";
                            InputStreamReader tempReader = new InputStreamReader(new BufferedInputStream(p.getInputStream()));
                            BufferedReader reader = new BufferedReader(tempReader);
                            while (true){
                                String line = reader.readLine();
                                if (line == null)
                                    break;
                                res += line + "\n";
                            }
                            reader.close();
                            parent.response.add("OUTPUT STREAM: " + res);
                            setProcess("STATUS: Executed/Called Successfully!");
                        }catch(Exception e) {
                            setProcess("STATUS: Error Calling [" + e +"]");
                            System.out.println("Error Shutting Down: " + e);
                            parent.response.add("STATUS: Error Calling [" + e +"]");
                        }
                    }
                    break;
                }
            }
        }catch(Exception e) {
            System.out.println("Exception Fetching Commands: " + e);
        }
    }
}


/**
 *
 * @author Administrator
 */
public class Daemon extends javax.swing.JFrame {

    /**
     * Creates new form ServerDaemon
     */
    public boolean runningScan;
    Timer scanTimer;
    public String serverName, serverIP;
    
    public Vector <String> response;
    public int responseCode;
    
    public void addText(String str) {
        jTextStatus.setText(jTextStatus.getText() + str + "\n");
    }    
    
    public Daemon() {
        initComponents();
        
        Dimension sd  = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(sd.width / 2 - this.getWidth()/ 2, sd.height / 2 - this.getHeight()/ 2);
        try { 
            InetAddress add = InetAddress.getLocalHost();
            serverName = add.getHostName();
            serverIP = add.getHostAddress();
            jLabelServerName.setText("DAEMON CONSOLE URL/NAME: [" + serverName + "]");
        }catch(Exception e) {
            ;
        }
        
        responseCode = 0;
        response = new Vector <String> ();
        
        runningScan = false;
        scanTimer = new Timer();
        ScanTimerTask scanTT = new ScanTimerTask(this);
        scanTimer.schedule(scanTT,1000,1000);        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabelServerName = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextServer = new javax.swing.JTextField();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextStatus = new javax.swing.JTextArea();
        jButton24 = new javax.swing.JButton();
        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextProcess = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jTextStatusBar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("DAEMON TOOL");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setText("E X I T");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabelServerName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelServerName.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelServerName.setText("CONSOLE URL/NAME: ");
        jLabelServerName.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Client Communication"));

        new LoadForm();

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ENTER SERVER NAME:");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTextServer.setText("localhost");

        jButton22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton22.setText("E N A B L E");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton23.setText("D I S A B L E");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("S T A T U S");
        jLabel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTextStatus.setColumns(20);
        jTextStatus.setEditable(false);
        jTextStatus.setRows(5);
        jScrollPane1.setViewportView(jTextStatus);

        jButton24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton24.setText("C L E A R");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jProgressBar1.setMaximum(10);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextServer, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton23))
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextServer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton22)
                    .addComponent(jButton23))
                .addGap(5, 5, 5)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton24)
                .addContainerGap())
        );

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Process Response"));

        new LoadForm();

        jTextProcess.setColumns(20);
        jTextProcess.setEditable(false);
        jTextProcess.setRows(5);
        jScrollPane2.setViewportView(jTextProcess);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setText("C L E A R");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addContainerGap())
        );

        jTextStatusBar.setEditable(false);
        jTextStatusBar.setForeground(new java.awt.Color(255, 0, 0));
        jTextStatusBar.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jTextStatusBar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelServerName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabelServerName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5)
                    .addComponent(jTextStatusBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
// TODO add your handling code here:
        runningScan = false;
        scanTimer.cancel();
        System.exit(0);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
// TODO add your handling code here:
        runningScan = true;
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
// TODO add your handling code here:
        jTextStatusBar.setText("");
        jTextProcess.setText("");
        jTextStatus.setText("");
        runningScan = false;
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
// TODO add your handling code here:
        jTextStatus.setText("");
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jTextProcess.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelServerName;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    public javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JTextArea jTextProcess;
    public javax.swing.JTextField jTextServer;
    public javax.swing.JTextArea jTextStatus;
    public javax.swing.JTextField jTextStatusBar;
    // End of variables declaration//GEN-END:variables
}
