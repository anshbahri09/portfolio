/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class PathSettings {
    //public static final String projectPath = "/home/ravee/Desktop/Current";
    public static final String projectPath = "D:\\JP12\\5071.UnixExplorer\\Current";
    
    public PathSettings() {
        ;
    }
}

