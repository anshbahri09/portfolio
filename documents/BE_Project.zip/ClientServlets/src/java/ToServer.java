/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import JavaLib.*;
import libPack.ServerCommand;
import libPack.ServerInfo;

/**
 *
 * @author Administrator
 */
public class ToServer extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ServerInfo si = new ServerInfo();
        ServerCommand sc = new ServerCommand();

        try
        {
            ObjectInputStream in1 = new ObjectInputStream(request.getInputStream());
            si = (ServerInfo)in1.readObject();
            in1.close();

            // set file name...
//            String fname = PathSettings.projectPath + "/To Servers/" + si.name;
            String fname = PathSettings.projectPath + "\\To Servers\\" + si.name;

            // check if any file exists...
            if(new File(fname).exists()) {
                ObjectInputStream in2 = new ObjectInputStream(new FileInputStream(fname));
                sc = (ServerCommand)in2.readObject();
                in2.close();
            }else {
                sc.sc.commandType = -1; // no commands available
            }

            ObjectOutputStream out1 = new ObjectOutputStream(response.getOutputStream());
            out1.writeObject(sc);
            out1.close();

            new File(fname).delete();
        } catch(Exception e) {
            sc.sc.commandType = -2; // error
            ObjectOutputStream out2 = new ObjectOutputStream(response.getOutputStream());
            out2.writeObject(sc);
            out2.close();
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        new LoadForm();
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        new LoadForm();
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
