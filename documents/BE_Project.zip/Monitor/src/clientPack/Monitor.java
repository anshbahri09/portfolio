package clientPack;

  
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import JavaLib.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import javax.swing.DefaultListModel;
import libPack.ServerCommand;
import libPack.ServerInfo;
import libPack.SingleCommand;
import libPack.SingleLog;

class MonitorTimerTask extends TimerTask {
    public Monitor parent;
    
    public MonitorTimerTask(Monitor parent) {
        this.parent = parent;
    }
    
    public void run() {
        if(!parent.runningMonitor) {
            parent.jProgressBar1.setIndeterminate(false);
            return;
        }
        
        parent.jProgressBar1.setIndeterminate(true);
        
        // see if some server are offline more than 5 seconds...
        if(parent.jCheckAutoRemove.isSelected()) {
            for(int i=0;i<parent.serverInfoDB.size();i++) {
                long timeNow = Calendar.getInstance().getTimeInMillis();
                long timeThen = parent.serverInfoDB.get(i).refreshTime.getTimeInMillis();
                if(((timeNow - timeThen)/1000) > 5)  {
                    parent.serverInfoDB.remove(i);
                    i--;
                }
            }
            parent.updateServers();
        }
        
        // monitor any server information
        File fromClientDir = new File(PathSettings.projectPath + "/From Servers");
        File clientRequests[] = fromClientDir.listFiles();
        for(int i=0;i<clientRequests.length;i++) {
            try {
                // read object
                ObjectInputStream in1 = new ObjectInputStream(new FileInputStream(clientRequests[i]));
                ServerInfo si = (ServerInfo)in1.readObject();
                in1.close();
                
                // process info
                parent.processServer(si);
                
                // delete file after using
                clientRequests[i].delete();
            }catch(Exception e) {
                System.out.println("Exception: " + e);
            }
        }
        
    }
}

class CommandTimerTask extends TimerTask {
    public Monitor parent;
    
    public CommandTimerTask(Monitor parent) {
        this.parent = parent;
    }
    
    public void run() {
        if(!parent.runningCommand) {
            return;
        }
        
        if(parent.serverCommandDB.size()!=0) {
            ServerCommand sc = parent.serverCommandDB.get(0);
            /// write cc to file....
            try {
                ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(PathSettings.projectPath + "/To Servers/" + sc.serverName));
                out.writeObject(sc);
                out.close();
            }catch(Exception e) {
                ;
            }
            parent.serverCommandDB.remove(0);
        }
    }
}

public class Monitor extends javax.swing.JFrame {
    MainForm parent;
    
    public boolean runningMonitor;
    Timer monitorTimer;
    
    public boolean runningCommand;
    Timer commandTimer;
    
    public DefaultListModel lmServers;
    public Vector <ServerInfo> serverInfoDB;
    public Vector <ServerCommand> serverCommandDB;

    public Vector <String> args;
    DefaultListModel lmArgs;
    DefaultListModel lmCommands;
    
    public Monitor(MainForm parent) {
        initComponents();
        this.parent = parent;
        
        Dimension sd  = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(sd.width / 2 - this.getWidth()/ 2, sd.height / 2 - this.getHeight()/ 2);
        
        SingleCommand sc = new SingleCommand();
        jComboType.removeAllItems();
        for(int i=0;i<sc.commandTypeDesc.length;i++) {
            jComboType.addItem(sc.commandTypeDesc[i]);
        }
        args = new Vector <String> ();
        lmArgs = new DefaultListModel();
        lmCommands = new DefaultListModel();

        loadArgs();
        loadCommands();

        runningMonitor = false;
        lmServers = new DefaultListModel();
        jListServers.setModel(lmServers);
        
        serverInfoDB = new Vector <ServerInfo> ();
        serverCommandDB = new Vector<ServerCommand> ();
        
        monitorTimer = new Timer();
        MonitorTimerTask monitorTT = new MonitorTimerTask(this);
        monitorTimer.schedule(monitorTT,100,500);
        
        commandTimer = new Timer();
        CommandTimerTask commandTT = new CommandTimerTask(this);
        commandTimer.schedule(commandTT,100,500);
    }
    
    public void loadArgs() {

        lmArgs.clear();
        for(int i=0;i<args.size();i++) {
            lmArgs.addElement(args.get(i));
        }
        jListArgs.setModel(lmArgs);
    }

    public void loadCommands() {
        lmCommands.clear();
        for(int i=0;i<parent.commandDB.list.size();i++) {
            SingleCommand sc = parent.commandDB.list.get(i);
            String str = sc.commandTypeDesc[sc.commandType] + " >> " + sc.commandDesc + " [" + sc.directory + "]" + ", ARGUMENTS: " + sc.command.size();
            lmCommands.addElement(str);
        }
        jListCommands.setModel(lmCommands);
    }

    public void processServer(ServerInfo si) {
        addServer(si);
        SingleCommand sc = new SingleCommand();
        if(si.responseCode!=0) {
            // some additional response received...
            
            addText("Server: " + si.name + ", RESPONSE FOR COMMAND TYPE: " + sc.commandTypeDesc[si.responseCode]);
            for(int i=0;i<si.response.response.size();i++) {
                addText(si.response.response.get(i));
            }
            SingleLog sl = new SingleLog();
            sl.si = si;
            parent.logDB.list.add(sl);
        }
    }
    
    public void addText(String str) {
        jTextMonitorStatus.setText(jTextMonitorStatus.getText() + str + "\n");
    }
    
    public void addServer(ServerInfo si) {
        boolean found = false;
        si.refreshTime = Calendar.getInstance(); // refresh update time...
        for(int i=0;i<serverInfoDB.size();i++) {
            if(serverInfoDB.get(i).name.equals(si.name)) {
                found = true;
                serverInfoDB.remove(i);
                serverInfoDB.add(i,si);
                break;
            }
        }
        if(!found) {
            serverInfoDB.add(si);
        }
        updateServers();
    }
    
    public void updateServers() {
        lmServers = new DefaultListModel();
        for(int i=0;i<serverInfoDB.size();i++) {
            lmServers.addElement("" + serverInfoDB.get(i).name);
        }
        jListServers.setModel(lmServers);
        
        if(serverInfoDB.size()>0) {
            jListServers.setSelectedIndex(0);
        }
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        new LoadForm();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListServers = new javax.swing.JList();
        jCheckAutoRemove = new javax.swing.JCheckBox();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextMonitorStatus = new javax.swing.JTextArea();
        jButton20 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jListCommands = new javax.swing.JList();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jComboType = new javax.swing.JComboBox();
        jTextDesc = new javax.swing.JTextField();
        jTextDir = new javax.swing.JTextField();
        jTextArg = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        jListArgs = new javax.swing.JList();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jProgressBar1 = new javax.swing.JProgressBar();
        jButton21 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(102, 255, 0))); // NOI18N

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Node List"));

        new LoadForm();

        jListServers.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListServers.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListServersValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jListServers);

        jCheckAutoRemove.setText("Auto Remove Inactive Servers");
        jCheckAutoRemove.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jCheckAutoRemove.setMargin(new java.awt.Insets(0, 0, 0, 0));

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                    .add(jCheckAutoRemove, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jCheckAutoRemove)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Node Response"));

        new LoadForm();

        jTextMonitorStatus.setColumns(20);
        jTextMonitorStatus.setEditable(false);
        jTextMonitorStatus.setRows(5);
        jScrollPane3.setViewportView(jTextMonitorStatus);
        new LoadForm();

        jButton20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton20.setText("UPDATE & CLEAR LOG");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel6Layout = new org.jdesktop.layout.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jButton20, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 612, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 612, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton20)
                .addContainerGap())
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Existing Commands"));

        new LoadForm();

        jListCommands.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListCommands.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListCommands.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListCommandsMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jListCommands);

        jButton3.setText("F I R E");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("F I R E    A L L");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel8Layout = new org.jdesktop.layout.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(jButton3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 291, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 30, Short.MAX_VALUE)
                        .add(jButton4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 291, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 612, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane4)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton3)
                    .add(jButton4))
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Custom Command"));

        new LoadForm();

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Command Type ");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Command Description ");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Command Directory ");
        jLabel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Command Arguments ");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jComboType.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jTextDesc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextDescActionPerformed(evt);
            }
        });

        jListArgs.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListArgs.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane5.setViewportView(jListArgs);

        jButton6.setText(">>");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton8.setText("Remove");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton1.setText("F I R E");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton9.setText("Rep.");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton2.setText("F I R E    A L L");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 125, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jComboType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 163, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jLabel2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jTextDesc))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jLabel5)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jTextDir))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jTextArg)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel11, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jButton8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel4Layout.createSequentialGroup()
                                .add(jButton6)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(jButton9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 66, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jButton2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jScrollPane5))))
                .addContainerGap())
        );

        jPanel4Layout.linkSize(new java.awt.Component[] {jLabel1, jLabel11, jLabel2, jLabel5}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jComboType, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(jTextDesc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel5)
                    .add(jTextDir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jLabel11)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jTextArg, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jButton6)
                            .add(jButton9))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jButton8))
                    .add(jScrollPane5, 0, 0, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jButton1)
                    .add(jButton2))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(new java.awt.Component[] {jLabel1, jLabel11, jLabel2, jLabel5}, org.jdesktop.layout.GroupLayout.VERTICAL);

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .add(11, 11, 11))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setText("B A C K");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton7.setText("S T O P");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton21.setText("S T A R T");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jButton21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 108, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jButton7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 108, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(jProgressBar1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(jButton5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 108, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jProgressBar1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jButton7)
                        .add(jButton21))
                    .add(jButton5))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(new java.awt.Component[] {jButton7, jProgressBar1}, org.jdesktop.layout.GroupLayout.VERTICAL);

        new LoadForm();

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("MONITOR");
        jLabel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1024, Short.MAX_VALUE)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel3)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
// TODO add your handling code here:
        jProgressBar1.setIndeterminate(true);
        runningCommand = true;
        runningMonitor = true;
        
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jListServersValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListServersValueChanged
// TODO add your handling code here:
    }//GEN-LAST:event_jListServersValueChanged

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
// TODO add your handling code here:
        
        jProgressBar1.setIndeterminate(false);
        
        runningCommand = false;
        runningMonitor = false;
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
// TODO add your handling code here:
        monitorTimer.cancel();
        commandTimer.cancel();
        parent.writeToLog();
        setVisible(false);
        parent.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jListCommandsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListCommandsMouseClicked
        // TODO add your handling code here:
        if(evt.getClickCount()!=2) {
            return;
        }
        int index = jListCommands.getSelectedIndex();
        if(index==-1) {
            return;
        }
        SingleCommand sc = parent.commandDB.list.get(index);
        jTextDesc.setText(sc.commandDesc);
        jTextDir.setText(sc.directory);
        jComboType.setSelectedIndex(sc.commandType);
        args.clear();
        for(int i=0;i<sc.command.size();i++) {
            args.add(sc.command.get(i));
        }
        loadArgs();
}//GEN-LAST:event_jListCommandsMouseClicked

    private void jTextDescActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextDescActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextDescActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        String arg = jTextArg.getText();
        if(arg.equals("")) {
            new MessageBox(this,"Please Enter A Valid String!").setVisible(true);
            return;
        }
        args.add(arg);
        loadArgs();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        int index = jListArgs.getSelectedIndex();
        if(index==-1) {
            return;
        }
        args.remove(index);
        loadArgs();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int indices[] = jListServers.getSelectedIndices();
        if(indices.length==0) {
            return;
        }

        for(int j=0;j<indices.length;j++) {
            ServerCommand sc = new ServerCommand();
            sc.serverName = serverInfoDB.get(indices[j]).name;
            sc.sc.commandType = jComboType.getSelectedIndex();
            sc.sc.directory = jTextDir.getText();
            sc.sc.commandDesc = jTextDesc.getText();
            for(int i=0;i<args.size();i++) {
                sc.sc.command.add(args.get(i));
            }
            addLog(sc);
            serverCommandDB.add(sc);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    public void addLog(ServerCommand sc) {
        SingleLog sl = new SingleLog();
        sl.si.name = sc.serverName;
        sl.si.response.response.add("COMMAND: " + sc.sc.commandDesc + " FOR " + sc.serverName + " TRIGGERED");
        addText("COMMAND: " + sc.sc.commandDesc + " FOR " + sc.serverName + " TRIGGERED");
        parent.logDB.list.add(sl);
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        int indices[] = jListServers.getSelectedIndices();
        if(indices.length==0) {
            return;
        }

        for(int j=0;j<indices.length;j++) {
            ServerCommand sc = new ServerCommand();
            sc.serverName  = serverInfoDB.get(indices[j]).name;
            int index = jListCommands.getSelectedIndex();
            if(index == -1) {
                return;
            }
            SingleCommand sc2 = parent.commandDB.list.get(index);
            sc.sc.commandType = sc2.commandType;
            sc.sc.directory = sc2.directory;
            sc.sc.commandDesc = sc2.commandDesc;
            for(int i=0;i<sc2.command.size();i++) {
                sc.sc.command.add(sc2.command.get(i));
            }
            addLog(sc);
            serverCommandDB.add(sc);
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        int index = jListArgs.getSelectedIndex();
        if(index==-1) {
            return;
        }
        String arg = jTextArg.getText();
        if(arg.equals("")) {
            new MessageBox(this,"Please Enter A Valid String!").setVisible(true);
            return;
        }
        args.remove(index);
        args.add(index, arg);
        loadArgs();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int indices[] = jListServers.getSelectedIndices();
        if(indices.length==0) {
            return;
        }

        for(int i=0;i<serverInfoDB.size();i++) {
            for(int j=0;j<indices.length;j++) {
                ServerCommand sc = new ServerCommand();
                sc.serverName = serverInfoDB.get(i).name; //serverInfoDB.get(indices[j]).name;
                sc.sc.commandType = jComboType.getSelectedIndex();
                sc.sc.directory = jTextDir.getText();
                sc.sc.commandDesc = jTextDesc.getText();
                for(int k=0;k<args.size();k++) {
                    sc.sc.command.add(args.get(k));
                }
                addLog(sc);
                serverCommandDB.add(sc);
            }
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        int indices[] = jListServers.getSelectedIndices();
        if(indices.length==0) {
            return;
        }

        for(int i=0;i<serverInfoDB.size();i++) {
            for(int j=0;j<indices.length;j++) {
                ServerCommand sc = new ServerCommand();
                sc.serverName  = serverInfoDB.get(i).name; //serverInfoDB.get(indices[j]).name;
                int index = jListCommands.getSelectedIndex();
                if(index == -1) {
                    return;
                }
                SingleCommand sc2 = parent.commandDB.list.get(index);
                sc.sc.commandType = sc2.commandType;
                sc.sc.directory = sc2.directory;
                sc.sc.commandDesc = sc2.commandDesc;
                for(int k=0;k<sc2.command.size();k++) {
                    sc.sc.command.add(sc2.command.get(k));
                }
                addLog(sc);
                serverCommandDB.add(sc);
            }
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20ActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    public javax.swing.JCheckBox jCheckAutoRemove;
    private javax.swing.JComboBox jComboType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JList jListArgs;
    public javax.swing.JList jListCommands;
    private javax.swing.JList jListServers;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    public javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextField jTextArg;
    private javax.swing.JTextField jTextDesc;
    private javax.swing.JTextField jTextDir;
    private javax.swing.JTextArea jTextMonitorStatus;
    // End of variables declaration//GEN-END:variables
    
}
