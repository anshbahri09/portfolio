// --*-c++-*--

#include <stdlib.h>
#include <mpi.h>
#include<assert.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <time.h>

#include "image.h"
#include "image_utils.h"

void parallel_mean(uint32_t *recv_buff,int width,int height,int windowSize)
{
   std::vector<uint32_t> tmp_data;
   for(int i=0;i<width*height;i++)
       tmp_data.push_back(recv_buff[i]);

   int edgex = windowSize/2;
   int edgey = windowSize/2;

   for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
         double sum = 0;
         int count = 0;
         for (int fx = 0; fx < windowSize; fx++) {
           for (int fy = 0; fy < windowSize; fy++) {
             int yy = y+fy-edgey;
             int xx = x+fx-edgex;
             if (yy < 0 || yy >= height || xx < 0 || xx >= width)
               continue;
             sum += (double)tmp_data.at((width*yy)+xx);
             count++;
           } 
         }
         assert(count != 0);
         recv_buff[(width*y)+x]= (uint32_t)(sum/count);
      }
   }
}

void parallel_median(uint32_t *recv_buff,int width,int height,int windowSize)
{

  std::vector<uint32_t> tmp_data;
     for(int i=0;i<width*height;i++)
       tmp_data.push_back(recv_buff[i]);
 
   int edgex = windowSize/2;
   int edgey = windowSize/2;

   for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
         std::vector<uint32_t> colorArray;
         for (int fx = 0; fx < windowSize; fx++) {
           for (int fy = 0; fy < windowSize; fy++) {
             int yy = y+fy-edgey;
             int xx = x+fx-edgex;
             if (yy < 0 || yy >= height || xx < 0 || xx >= width)
               continue;
             colorArray.push_back (tmp_data.at((width*(y+fy-edgey)+(x+fx-edgex))));
           } 
         }
         sort (colorArray.begin(), colorArray.end());
         assert(colorArray.size() != 0);
         recv_buff[(width*y)+x] = colorArray[colorArray.size()/2];
      }
   }
}

std::string parallel_main(int argc, char* argv[])
{
  if (argc < 5) {
    std::cout << "usage: " << argv[0] << " "
	      << "<in image> <out image> <filter type> <window size>"
              << std::endl;
    std::cout << " filter type = {mean|median} " << std::endl;
    exit(-1);
  }
  int rank,namelen,num_procs;
  char processor_name[MPI_MAX_PROCESSOR_NAME];
  
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Get_processor_name(processor_name, &namelen);
  MPI_Comm_size(MPI_COMM_WORLD,&num_procs);

  std::string inFilename(argv[1]);
  std::string outFilename(argv[2]);
  std::string filterType(argv[3]);
  int windowSize = atoi(argv[4]);

  outFilename = "p_" + outFilename;
  
  uint32_t *buff = NULL;
  int height = 0,width = 0;
  Image input,output;
  
  if (rank == 0) {
    std::cout << "* doing parallel image filtering ** " << std::endl;
    std::cout << "* reading regular tiff: " << argv[1] << std::endl;
    input.load_tiff(std::string(argv[1]));
    output=input;
    output.make_greyscale();
    height=output.height();
    width=output.width();
    buff = (uint32_t *) malloc(sizeof(uint32_t)*height*width);
    buff=output.get_addr();
  }
  
  MPI_Bcast(&height,1,MPI_INT,0,MPI_COMM_WORLD);
  MPI_Bcast(&width,1,MPI_INT,0,MPI_COMM_WORLD);
  MPI_Bcast(&num_procs,1,MPI_INT,0,MPI_COMM_WORLD);
 
  int up= windowSize/2;
  int down=windowSize;
  int chunk=height/num_procs;
  int *send_size=(int *) malloc(sizeof(int)*num_procs);
  int *chunk_size=(int *) malloc(sizeof(int)*num_procs); 
  int i;
  for(i=0;i<num_procs-1;i++)
  {
    if(i==0)
      up=0;

    send_size[i]=(up+chunk+down)*width;
    
    if(i==0)
       chunk_size[i]=0;
    else
       chunk_size[i]= (i*chunk-up)*width;

   up=windowSize/2;   
  }

   if(num_procs == 1)
	up = 0;

   send_size[i]=(up+chunk+(height%num_procs))*width;
   chunk_size[i]=(i*chunk-up)*width;
   uint32_t *recv_buff=(uint32_t *)malloc(sizeof(uint32_t)*(send_size[rank]));

   MPI_Scatterv(buff,send_size,chunk_size,MPI_UNSIGNED,recv_buff,send_size[rank],MPI_UNSIGNED,0,MPI_COMM_WORLD);

  time_t now;
  time(&now);

  std::cout << "[" << processor_name << "] processing with filter: " 
	    << filterType << " at time: "<<ctime(&now)<<" sendsize: "<<send_size[i]<<" height: "<<height
<<"Chunk Size: "<<chunk_size[i]<<" recv_start: "<<recv_buff<<" send_size[rank]: "<<send_size[rank]<<" rank: "<<rank<<std::endl;

  if (filterType == "mean") {
    parallel_mean(recv_buff,width,send_size[rank]/width,windowSize); 
  }
  else if (filterType == "median") {
     parallel_median(recv_buff,width,send_size[rank]/width,windowSize);
  }

  int disp = 0;
  int *rreceive=(int*)malloc(sizeof(int)*num_procs);
  i = 0;
  while(i < num_procs)
  {
    chunk_size[i]= i*chunk*width;
    if(i<num_procs-1)
      rreceive[i]=(height/num_procs)*width;
    else 
      rreceive[i]= ((height/num_procs)+(height%num_procs))*width;
    i++;
  }
 
  int send_count;	
  if(rank != 0)
    disp=(windowSize/2)*width;
  else
    disp=0;

  int rows_proc = height / num_procs;
  int extra_rows = height % num_procs;

  if(rank != num_procs - 1 )
    send_count= (rows_proc)*width;
  else
    send_count= ((rows_proc)+(extra_rows))*width;
        
  MPI_Gatherv(recv_buff+disp,send_count,MPI_UNSIGNED,buff,rreceive,chunk_size,MPI_UNSIGNED,0,MPI_COMM_WORLD);
  
  if (rank == 0) 
  {
	output.set_data(buff,width*height);
    std::cout << "[" << processor_name << "] saving image: " 
              << outFilename 
              << std::endl;
    output.save_tiff_grey_8bit(outFilename);
  }
  std::cout << "-- done --" << std::endl;
	
  return outFilename;
}
