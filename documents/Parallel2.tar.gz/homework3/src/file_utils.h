// --*-c++-*--

#ifndef _FILE_UTILS_H
#define _FILE_UTILS_H

int compare_two_binary_files(const char *f1, const char *f2);

#endif 
