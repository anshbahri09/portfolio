package assignment2;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

class MainFrame extends JFrame{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	JLabel LogoLabel;
	JLabel headLabel;
	JButton notifyButton;
	LoginPanel loginPanel;
	SignupPanel signUpPanel;
	SqlPanel sqlPanel;
	ButtonPanel buttonPanel;
//	PostandSearchPanel postandsearch;
	ResultPanel resultPanel;
	Connection conn=null;
	ArrayList<String> requester = new ArrayList<String>();
	ArrayList<String> Relation= new ArrayList<String>();
	int countrequest=0;
	JTextArea resultArea = null;
	JScrollPane scrollPane = null;
	int trigger = 0;
	JLabel showLabel;
	int hasRequest = 0;
	StringBuffer SQLOut = new StringBuffer ();
	MainFrame(){
		setResizable(false);
		setLayout(null);
		setSize(1100, 700);
		int width=Toolkit.getDefaultToolkit().getScreenSize().width;
		int height=Toolkit.getDefaultToolkit().getScreenSize().height;
		setLocation((width-1100)/2,(height-700)/2);
		setTitle("This is GUI for database homework");
		SetLogo();
		setLoginPanel();
		setSignupPanel();
		setSqlPanel();
		setButtonPanel();
		setResultPanel();
	//	postandsearch.disablePanel();
		buttonPanel.disablePanel();
	}

	public void disableResult(){
    	resultArea.setText("");
    	resultArea.setEditable(false);
    	resultArea.setEnabled(false);
    	scrollPane.setEnabled(false);
	}

	public void setResultPanel(){

		resultArea = new JTextArea(10,30);
		resultArea.setLineWrap(true);
		scrollPane = new JScrollPane(resultArea);
		headLabel = new JLabel("Shopping System");
		add(scrollPane);
		add(headLabel);
		
		headLabel.setFont(new Font("Serif", Font.BOLD, 30));
		headLabel.setBounds(240,20 , 360, 60);
		scrollPane.setBounds(20, 100,740, 250);
	}

	public void SetLogo(){
	Image image;
	try {
		image = ImageIO.read(new File("usc_viterbi_logo.jpg"));
		ImageIcon icon = new ImageIcon(image);
		LogoLabel = new JLabel();
		LogoLabel.setIcon(icon);
		LogoLabel.setBounds(830,500,300,150);

		add(LogoLabel);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  //this generates an image file

	}

	

	public void setButtonPanel(){
		buttonPanel = new ButtonPanel();
		buttonPanel.setBounds(30, 380, 700, 90);
		this.add(buttonPanel);

		
		buttonPanel.buttons[0].addActionListener(new ActionListener() {
	          
            public void actionPerformed(ActionEvent e) {
            	StringBuffer result= new StringBuffer();
            	/*Fill this function*/
            	/*Press this your account button, you should be able to list*/
            	/* current log in customer information in the result panel (Including Email, First Name, Last Name, Address)*/
            	/*You can define the output format*/


            }
        });
		
		buttonPanel.buttons[1].addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
            	StringBuffer result= new StringBuffer();
            	/*Fill this function*/
            	/*Press this all products button, you should be able to list all the products which are visible to you*/
            	/*You can define the output format*/


            }
        });

		buttonPanel.buttons[2].addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
            	final Frame0 frame=new Frame0();
                frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                frame.setVisible(true);
                frame.btn1.addActionListener(new ActionListener() {
                 
                    public void actionPerformed(ActionEvent e) {
                    	/*Fill this function*/
    	            	/*Press this choose category Button, after choosing and pressing OK*/
    	            	/* you should be able to list all products belong to this category*/
                    	
                    }
                });
            }
        });

		
		buttonPanel.buttons[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	        	final Frame1 frame=new Frame1("Please input Price Range ");
	            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	            frame.setVisible(true);

	            frame.btn1.addActionListener(new ActionListener() {
	               
	                public void actionPerformed(ActionEvent e) {
	                	/*Fill this function*/
	                	/*Press this set price range Button, you should be able to set price range*/
	                	/*Pressing "Set Price Range" button, a new window will pop out. */
	                	/*Then you can enter "Min_Price" & "Max_Price" and press "Search" button, */
	                	/*and then all products belong to category that you choose should be shown in the result panel.*/
	                	
	                }
	            });

	        }
			});
            
     

		buttonPanel.buttons[4].addActionListener(new ActionListener() {
           
        public void actionPerformed(ActionEvent e) {
        	final Frame2 frame=new Frame2();
            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            frame.setVisible(true);

            frame.btn1.addActionListener(new ActionListener() {
               
                public void actionPerformed(ActionEvent e) {
                	/*Fill this function*/     
//                	Press "Order Products" button, a new window will pop out. 
//                	Then you can enter "Product ID" and "Quantity", and then you press continue, 
//                	the Total Price should be shown correctly. 
//                	Then, you can press "Place Order" to complete this order. 
//                	This new order should be synchronized in the database.
                }
            });


            frame.btn2.addActionListener(new ActionListener() {
           
                public void actionPerformed(ActionEvent e) {
                	/*Fill this function*/
                	/*Press this accept all Button, you should be able to accept all friend request and add this information into friend relationship table*/
                	/*pop up a standard dialog box to show <succeed or failed>*/
                }
            });

        }
		});

		buttonPanel.buttons[5].addActionListener(new ActionListener() {
	          
            public void actionPerformed(ActionEvent e) {
            	StringBuffer result= new StringBuffer();
            	/*Fill this function*/
            	/*Press "Your Orders", all order history of this customer should be shown in the result panel.*/


            }
        });

		
		buttonPanel.buttons[6].addActionListener(new ActionListener() {
	           
	        public void actionPerformed(ActionEvent e) {
	        	final Frame5 frame=new Frame5("Product ID : ","Review : ");
	            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	            frame.setVisible(true);

	            frame.btn1.addActionListener(new ActionListener() {
	               
	                public void actionPerformed(ActionEvent e) {
	                	/*Fill this function*/
	                	/*Press "Review Products" button, a new window will pop out. */
	                	/*Input product ID and review content and press the OK button, this information should be inserted into database.*/
	                	
	                }
	            });


	        }
			});
		buttonPanel.buttons[7].addActionListener(new ActionListener() {
	           
	        public void actionPerformed(ActionEvent e) {
	        	final Frame4 frame=new Frame4("Product ID : ","Submit");
	            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	            frame.setVisible(true);

	            frame.btn1.addActionListener(new ActionListener() {
	               
	                public void actionPerformed(ActionEvent e) {
	                	/*Fill this function*/
	                	/*Press "List All Reviews" button, a new window will pop out. */
	                	/*Input "Product ID" and press submit, all reviews about this product should be shown in the result panel.*/
	                	
	                }
	            });


	            

	        }
			});
		
		buttonPanel.buttons[8].addActionListener(new ActionListener() {
	           
	        public void actionPerformed(ActionEvent e) {
	        	final Frame4 frame=new Frame4("Review ID : ","Like it");
	            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	            frame.setVisible(true);

	            frame.btn1.addActionListener(new ActionListener() {
	               
	                public void actionPerformed(ActionEvent e) {
	                	/*Fill this function*/
	                	/*Press "Like Reviews" button, a new window will pop out. */
	                	/*Input "Review ID" and press "Like it", this information should be inserted into database.*/
	                	
	                }
	            });


	            

	        }
			});	
		
		buttonPanel.buttons[9].addActionListener(new ActionListener() {
	          
            public void actionPerformed(ActionEvent e) {
            	StringBuffer result= new StringBuffer();
            	/*Fill this function*/
            	/*Press "List All Likes" button, all reviews that liked by this customer should be shown in the result panel.*/


            }
        });
		buttonPanel.buttons[10].addActionListener(new ActionListener() {
	          
            public void actionPerformed(ActionEvent e) {
            	StringBuffer result= new StringBuffer();
            	/*Fill this function*/
            	/*Press "Nearest Seller" button, the nearest seller info for this customer should be shown in the result panel.*/
            	/*This is a spatial query*/

            }
        });
		
		buttonPanel.buttons[11].addActionListener(new ActionListener() {
           
            public void actionPerformed(ActionEvent e) {
            	final Frame3 frame=new Frame3("Please input coordinate: ");
                frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                frame.setVisible(true);

                frame.btn1.addActionListener(new ActionListener() {
                  
                    public void actionPerformed(ActionEvent e) {
                    	/*Fill this function*/
                    	/*Press this Button, input left top corner coordinate and right down corner coordinate*/
                    	/*press ok, you should be able list the information(including address information) about seller who lives in this area. Close query window*/
                    	/*This is a spatial query*/
                    	
                    }
                });
            }
        });
		
	}

	
	public void setSQLOutput(StringBuffer sb)
	{
		sqlPanel.SQLArea.setText(sb.toString());
		sqlPanel.SQLArea.setEnabled(true);
	}
	public void setSqlPanel(){
		sqlPanel = new SqlPanel();
		showLabel = new JLabel("The corresponding SQL sentence:");
		showLabel.setBounds(30, 490, 400, 20);
		sqlPanel.setBounds(5, 515,790, 150);
		this.add(sqlPanel);
		this.add(showLabel);
	}

	public void setLoginPanel(){
		loginPanel = new LoginPanel();
		this.add(loginPanel);

		loginPanel.signup.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		           signUpPanel.enablePanel();
			}
        });
        loginPanel.login.addActionListener(new ActionListener() {
           
            public void actionPerformed(ActionEvent e) {  
            //	buttonPanel.enablePanel();
            	/*Fill this function*/
            	/*Press this Button, you should be able match the user information. If valid, keep the user email information(but can't modified) and clear the password*/
            	/*If invalid, you should pop up a dialog box to notify user, then enable signup panel for user to register*/
            	/*After logged in, you should change this button's function as logout which means disable all the panel, return to the original state*/
            	if(trigger==0){
               	 //match account
               	 conn=ConnectDB.openConnection();
               	 String QueryStr = "select EMAIL from Member where Email='"+loginPanel.username.getText()+"' and passwd = '"+loginPanel.password.getText()+"'";
               	 SQLOut.append(QueryStr+"\n\n");
               	 try {
   					Statement stmt = conn.createStatement();
   					ResultSet re = stmt.executeQuery(QueryStr);
   					 if(re.next())
   	            	 {
   	            		 loginPanel.setUserName(loginPanel.username.getText().toString());
   	            		 loginPanel.disablePanel();
   	            		 loginPanel.password.setText("");
   	            		 trigger = 1;
   	            		 loginPanel.login.setText("logout");
   	            		 signUpPanel.disablePanel();
   	            		 buttonPanel.enablePanel();
  	            		 loginPanel.signup.setEnabled(false);

   	            	 }
   	            	 else
   	            	 {
  	            		 JOptionPane.showMessageDialog(null, "No ... please signup");
   	            		 signUpPanel.enablePanel();
   	            		// loginPanel.disablePanel();
   	            	}
   					 ConnectDB.closeConnection(conn);

   				} catch (SQLException e1) {
   					// TODO Auto-generated catch block
   					e1.printStackTrace();
   					ConnectDB.closeConnection(conn);
   					return;
   				}

               	//getnotification


               }else{
               	loginPanel.login.setText("login");
               	loginPanel.enablePanel();
               	loginPanel.signup.setEnabled(true);
               	loginPanel.password.setText("");
               	loginPanel.username.setText("");
               	disableResult();
               	trigger = 0;
               	buttonPanel.disablePanel();
           	}
               	setSQLOutput(SQLOut);
              	}

           });
   

	}

	public void setSignupPanel(){

		signUpPanel = new SignupPanel();
		this.add(signUpPanel);
		signUpPanel.signup.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {  
            	/*Fill this function*/
            	/*Press this signup button, you should be able check whether current account is existed. If existed, pop up an error, if not check input validation(You can design this part according to your database table's restriction) create the new account information*/
            	/*pop up a standard dialog box to show <succeed or failed>*/
            	
            }
        });

		signUpPanel.disablePanel();

	}


}


class ConnectDB{

	public static Connection openConnection(){
        try{
	        String driverName = "oracle.jdbc.driver.OracleDriver";
	        Class.forName(driverName);

	        //set the username and password for your connection.
	        String url = "jdbc:oracle:thin:@localhost:1521:orcl";
	        String uname = "homework2";
	        String pwd = "123";

	        return DriverManager.getConnection(url, uname, pwd);
        }
        catch(ClassNotFoundException e){
        	System.out.println("Class Not Found");
        	e.printStackTrace();
        	return null;
        }
        catch(SQLException sqle){
        	System.out.println("Connection Failed");
        	sqle.printStackTrace();
        	return null;
        }

	}
	public static void closeConnection(Connection conn)
	{
		try{
		 conn.close();
	 }
	    catch (Exception e){
	    	e.printStackTrace();
	    	System.out.println("connection closing error ");
	    }
	}
}
public class Assignment2 {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	MainFrame frame = new MainFrame();
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
